#!/bin/bash

export NUM_ROBOTS=5
export ENV_NAME=empty
export SPAWN_POSE_DOC=positions.txt
export GZ_VERSION=garden
